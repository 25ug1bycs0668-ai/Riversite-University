# MediCare Hospital Management System (Demo)

A responsive browser-based hospital administration demo built with HTML5, CSS3 and vanilla JavaScript. No build step or server is required.

## Run it
1. Extract `hospital-management-system.zip`.
2. Open the extracted folder in VS Code.
3. Open `index.html` directly in a browser, or use the VS Code Live Server extension.
4. Use the left navigation to open Patients, Doctors, Appointments, Billing, Pharmacy, Laboratory, Reports, and Settings.

## Included
- Dashboard cards and upcoming appointment list
- Patient and doctor create/edit/delete flows
- Appointment booking with past-date and doctor/time conflict checks
- Invoice totals calculated from charges, discounts, tax and payments
- Pharmacy inventory with dispense action and low-stock alerts
- Laboratory order tracking with explicit demo-result notice
- CSV export, print views, search, LocalStorage persistence
- Responsive sidebar, tables, forms, and modal dialogs

## Demo data
Sample records are fictional. Data is stored in browser LocalStorage under `medicare_demo_v1`. Use Settings to restore sample data or clear demo data. Storage is specific to the browser/profile and is not a shared database.

## Important security notice
This is a front-end demonstration, not production hospital software. LocalStorage and client-side JavaScript do not provide secure authentication, server-enforced authorization, encryption, audit logs, or compliant medical-record storage. Do not enter real patient data, passwords, payment details, or confidential clinical information. A production system needs a secure backend, server-side identity/roles, appropriate encryption, backups, audit logging, and legal/privacy/security review.

## Notes
- Dashboard appointment chart uses illustrative sample values and is labelled as demo activity.
- Demo login is not implemented in this build; do not mistake the profile label for authenticated access.
- Always clinically review laboratory information; demo data is not medical advice.
