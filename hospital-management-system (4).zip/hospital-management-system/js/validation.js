const Validation = {
  required(value,label){if(!String(value??"").trim())throw Error(`${label} is required.`);return String(value).trim()},
  phone(value){const v=String(value||"").trim();if(v&&!/^[+()\d\s-]{7,18}$/.test(v))throw Error("Enter a valid phone number.");return v},
  email(value){const v=String(value||"").trim();if(v&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))throw Error("Enter a valid email address.");return v},
  number(value,label,{min=0,max=1e9,integer=false}={}){const n=Number(value);if(!Number.isFinite(n)||n<min||n>max||(integer&&!Number.isInteger(n)))throw Error(`${label} must be ${integer?"a whole number":"a valid number"} between ${min} and ${max}.`);return n},
  dateNotPast(value){if(value<todayISO())throw Error("Please choose today or a future date.");return value}
};