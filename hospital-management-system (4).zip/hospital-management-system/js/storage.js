/* Demo storage only. Never store real medical records or passwords here. */
const Store = (() => {
  const KEY = "medicare_demo_v1";
  const seed = {
    patients: [
      {id:"PAT-1001",name:"Aarav Sharma",age:34,gender:"Male",phone:"9876543210",email:"aarav@example.com",address:"Chennai, Tamil Nadu",emergency:"9876500001",allergies:"None reported",reason:"Routine checkup",createdAt:"2026-10-25"},
      {id:"PAT-1002",name:"Diya Iyer",age:28,gender:"Female",phone:"9876543211",email:"diya@example.com",address:"Tambaram, Tamil Nadu",emergency:"9876500002",allergies:"Penicillin (reported)",reason:"Headache",createdAt:"2026-10-26"},
      {id:"PAT-1003",name:"Kabir Kumar",age:46,gender:"Male",phone:"9876543212",email:"kabir@example.com",address:"Chengalpattu, Tamil Nadu",emergency:"9876500003",allergies:"None reported",reason:"Follow-up",createdAt:"2026-10-27"}
    ],
    doctors: [
      {id:"DOC-201",name:"Dr. Meera Nair",specialization:"Cardiology",qualification:"MD, DM",phone:"9000010001",email:"meera@medicare.demo",department:"Cardiology",availability:"Available"},
      {id:"DOC-202",name:"Dr. Arjun Rao",specialization:"General Medicine",qualification:"MBBS, MD",phone:"9000010002",email:"arjun@medicare.demo",department:"General Medicine",availability:"Available"},
      {id:"DOC-203",name:"Dr. Sana Khan",specialization:"Pediatrics",qualification:"MBBS, DCH",phone:"9000010003",email:"sana@medicare.demo",department:"Pediatrics",availability:"Unavailable"}
    ],
    appointments: [
      {id:"APT-301",patientId:"PAT-1001",doctorId:"DOC-201",date:"2026-10-29",time:"10:00",reason:"Routine checkup",status:"Confirmed"},
      {id:"APT-302",patientId:"PAT-1002",doctorId:"DOC-202",date:"2026-10-29",time:"11:30",reason:"Headache",status:"Scheduled"},
      {id:"APT-303",patientId:"PAT-1003",doctorId:"DOC-203",date:"2026-10-27",time:"09:00",reason:"Follow-up",status:"Completed"}
    ],
    invoices: [
      {id:"INV-401",patientId:"PAT-1001",consultation:800,lab:450,medicine:0,room:0,discount:0,tax:0,payment:1250,paymentMethod:"UPI",status:"Paid",date:"2026-10-25"},
      {id:"INV-402",patientId:"PAT-1002",consultation:700,lab:900,medicine:250,room:0,discount:50,tax:0,payment:500,paymentMethod:"Cash",status:"Partially Paid",date:"2026-10-26"}
    ],
    medicines: [
      {id:"MED-501",name:"Paracetamol 500mg",batch:"PCM-1026",quantity:120,price:2.5,supplier:"HealthPlus",expiry:"2027-06-30"},
      {id:"MED-502",name:"Cetirizine 10mg",batch:"CTZ-0626",quantity:8,price:4,supplier:"MedSupply",expiry:"2027-02-15"},
      {id:"MED-503",name:"ORS Sachet",batch:"ORS-0926",quantity:45,price:18,supplier:"HealthPlus",expiry:"2026-12-31"}
    ],
    labs: [
      {id:"LAB-601",patientId:"PAT-1001",test:"Complete Blood Count (CBC)",date:"2026-10-25",status:"Completed",result:"Demonstration result — clinician review required"},
      {id:"LAB-602",patientId:"PAT-1002",test:"Blood Glucose",date:"2026-10-27",status:"Pending",result:""}
    ]
  };
  let data;
  function load(){
    try { const raw=localStorage.getItem(KEY); data=raw?JSON.parse(raw):structuredClone(seed); if(!data||typeof data!=="object") throw Error("bad data"); }
    catch(e){ data=structuredClone(seed); try{localStorage.removeItem(KEY)}catch(_){} }
    ["patients","doctors","appointments","invoices","medicines","labs"].forEach(k=>{if(!Array.isArray(data[k]))data[k]=[]});
    return data;
  }
  function save(){ try{localStorage.setItem(KEY,JSON.stringify(data));return true}catch(e){console.error(e);return false} }
  function all(type){return data[type]||[]}
  function get(type,id){return all(type).find(x=>x.id===id)}
  function upsert(type,item){const list=all(type),i=list.findIndex(x=>x.id===item.id);if(i<0)list.unshift(item);else list[i]=item;save();return item}
  function remove(type,id){data[type]=all(type).filter(x=>x.id!==id);save()}
  function nextId(prefix,type){const nums=all(type).map(x=>Number(String(x.id).split("-").pop())).filter(Number.isFinite);return prefix+"-"+(Math.max(0,...nums)+1)}
  load();
  return {load,save,all,get,upsert,remove,nextId};
})();
const money = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(n)||0);
const todayISO = () => { const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
const esc = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const personName = id => Store.get("patients",id)?.name || "Unknown patient";
const doctorName = id => Store.get("doctors",id)?.name || "Unknown doctor";
const statusClass = s => "status-"+String(s||"pending").toLowerCase().replace(/[^a-z]+/g,"-");