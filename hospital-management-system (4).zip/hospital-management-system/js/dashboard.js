function renderDashboard(){
  const patients=Store.all("patients"),doctors=Store.all("doctors"),appts=Store.all("appointments"),invoices=Store.all("invoices");
  const today=todayISO(),todayAppts=appts.filter(a=>a.date===today),completed=appts.filter(a=>a.status==="Completed").length,pending=appts.filter(a=>["Scheduled","Confirmed"].includes(a.status)).length;
  const outstanding=invoices.reduce((s,i)=>s+Math.max(0,invoiceTotal(i)-Number(i.payment||0)),0);
  const monthNames=["May","Jun","Jul","Aug","Sep","Oct","Nov"],vals=[4,7,5,9,6,10,8];
  return `<div class="page-heading"><div><div class="eyebrow">OVERVIEW</div><h1>Good morning, Admin 👋</h1><p>Here’s what’s happening at your hospital today.</p></div><div class="heading-actions"><button class="btn" data-action="export" data-type="patients">⇩ Export data</button><button class="btn btn-primary" data-action="open-modal" data-kind="appointment">＋ Book appointment</button></div></div>
  <div class="stats-grid">
    ${stat("Registered patients",patients.length,"♙","blue","All patient records")}
    ${stat("Medical staff",doctors.length,"⚕","teal",`${doctors.filter(d=>d.availability==="Available").length} available now`)}
    ${stat("Today's appointments",todayAppts.length,"▣","orange",`${pending} scheduled / confirmed`)}
    ${stat("Outstanding balance",money(outstanding),"₹","purple","Across unpaid invoices")}
  </div>
  <div class="dashboard-grid">
    <section class="panel"><div class="panel-head"><div><h2>Appointment overview</h2><p>Illustrative monthly activity · demo data</p></div><span class="pill">Last 7 months</span></div>
      <div class="chart-area">${vals.map((v,i)=>`<div class="chart-col"><div class="chart-bars"><div class="bar" style="height:${v*8}%"></div><div class="bar alt" style="height:${Math.max(8,v*6-5)}%"></div></div><small>${monthNames[i]}</small></div>`).join("")}</div>
      <div class="legend"><span><i class="blue"></i>Appointments</span><span><i class="teal"></i>Completed</span></div>
    </section>
    <section class="panel"><div class="panel-head"><div><h2>Upcoming appointments</h2><p>Your next scheduled visits</p></div><button class="text-link" data-page="appointments">View all →</button></div>
      <div class="appointment-list">${appts.filter(a=>a.date>=today&&!["Cancelled","Completed","No-show"].includes(a.status)).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).slice(0,4).map(a=>`<div class="appointment-row"><div class="date-chip"><b>${esc(a.date.slice(8))}</b><small>${new Date(a.date+"T12:00:00").toLocaleDateString("en",{month:"short"})}</small></div><div class="appt-person"><b>${esc(personName(a.patientId))}</b><small>${esc(doctorName(a.doctorId))} · ${esc(a.time)}</small></div><span class="status ${statusClass(a.status)}">${esc(a.status)}</span></div>`).join("")||`<div class="empty-state"><div class="empty-icon">▣</div><b>No upcoming appointments</b><p>New bookings will appear here.</p><button class="btn btn-primary" data-action="open-modal" data-kind="appointment">Book appointment</button></div>`}</div>
    </section>
  </div>
  <section class="panel"><div class="panel-head"><div><h2>Recently registered patients</h2><p>Latest patient records added to the system</p></div><button class="text-link" data-page="patients">All patients →</button></div>
    ${patients.length?`<div class="table-wrap"><table><thead><tr><th>Patient</th><th>Patient ID</th><th>Contact</th><th>Registered</th><th>Action</th></tr></thead><tbody>${patients.slice(0,5).map(p=>`<tr><td><div class="person-cell"><div class="mini-avatar">${initials(p.name)}</div><div><b>${esc(p.name)}</b><small>${esc(p.age)} years · ${esc(p.gender)}</small></div></div></td><td>${esc(p.id)}</td><td>${esc(p.phone||"—")}</td><td>${esc(p.createdAt||"—")}</td><td><button class="btn btn-sm" data-action="view" data-type="patients" data-id="${esc(p.id)}">View</button></td></tr>`).join("")}</tbody></table></div>`:`<div class="empty-state"><b>No patient records yet</b><p>Add a patient to get started.</p><button class="btn btn-primary" data-action="open-modal" data-kind="patient">＋ Add patient</button></div>`}
  </section>`;
}
function stat(label,value,icon,color,foot){return `<article class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon ic-${color}">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></article>`}
function initials(name){return String(name||"?").split(/\s+/).slice(0,2).map(s=>s[0]||"").join("").toUpperCase()}